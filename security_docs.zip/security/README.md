# Seguridad del Proyecto – Fintech (Simulación NoCountry)

Este directorio contiene la documentación de seguridad necesaria para el correcto funcionamiento del proyecto fintech del equipo.

Incluye políticas, checklist de hardening, manejo de AppKey y estandarización de configuración segura.

## 📂 Contenido

- `checklist-seguridad.md` → Lista completa de verificación de seguridad para infra y APIs.
- `arquitectura-appkey.md` → Diagrama y explicación del funcionamiento de la AppKey.
- `.env.example` → Archivo de ejemplo para configurar variables de entorno sin exponer secretos.
- `policies/` → Políticas de seguridad divididas por áreas:
  - `api-hardening.md`
  - `infra-hardening.md`
  - `roles-permisos.md`

## 🚀 Cómo usar este directorio

1. Leer primero `checklist-seguridad.md`.  
2. Configurar un archivo `.env` local basado en `.env.example`.  
3. Seguir las políticas de seguridad antes de mergear código o hacer deploy.  
4. Mantener este directorio actualizado si se agregan nuevos endpoints, claves o configuraciones sensibles.
